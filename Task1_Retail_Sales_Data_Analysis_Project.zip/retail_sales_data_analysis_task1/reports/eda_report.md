# Retail Sales EDA Report\n\n## Data quality\n- Raw rows: 352\n- Clean rows: 345\n- Duplicate rows removed: 2\n- Missing quantity rows excluded: 5\n\n## KPI summary\n- **Raw Rows**: 352\n- **Clean Rows**: 345\n- **Duplicate Rows Removed**: 2\n- **Total Revenue**: 2299716.62\n- **Average Order Revenue**: 6665.85\n- **Top Product**: Monitor\n- **Top Region**: East\n- **Date Start**: 2025-01-01\n- **Date End**: 2025-12-31\n\n## Revenue by product\n\n| Product        |          Revenue |
|:---------------|-----------------:|
| Monitor        |      1.53856e+06 |
| USB-C Hub      | 267862           |
| Keyboard       | 222312           |
| Laptop Stand   | 157046           |
| Wireless Mouse | 113934           |\n\n## Revenue by region\n\n| Region   |   Revenue |
|:---------|----------:|
| East     |  564345   |
| South    |  521429   |
| West     |  504204   |
| North    |  479654   |
| Central  |  175610   |
| Unknown  |   54475.1 |\n\n## Monthly revenue\n\n| Month   |   Revenue |
|:--------|----------:|
| 2025-01 |    188004 |
| 2025-02 |    135633 |
| 2025-03 |    311928 |
| 2025-04 |    159323 |
| 2025-05 |    262825 |
| 2025-06 |    114537 |
| 2025-07 |    255213 |
| 2025-08 |    196888 |
| 2025-09 |    177296 |
| 2025-10 |    144891 |
| 2025-11 |    218686 |
| 2025-12 |    134490 |\n\n## Interpretation\n- Product and regional rankings are based on total calculated revenue.\n- Monthly totals help reveal seasonality, growth, or dips; confirm patterns with more years of data.\n- Synthetic sample data is for demonstrating the workflow, not for real business decisions.\n
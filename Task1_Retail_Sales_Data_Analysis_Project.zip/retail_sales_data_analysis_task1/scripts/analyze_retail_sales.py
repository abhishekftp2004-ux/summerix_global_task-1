"""
Retail Sales Data Analysis - Task 1
Run from project root: python scripts/analyze_retail_sales.py
"""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "datasets" / "raw" / "retail_sales_raw.csv"
CLEAN = ROOT / "datasets" / "cleaned" / "retail_sales_clean.csv"
FIGURES = ROOT / "reports" / "figures"
REPORTS = ROOT / "reports"
FIGURES.mkdir(parents=True, exist_ok=True)
REPORTS.mkdir(parents=True, exist_ok=True)

def load_data(path=RAW):
    """Load CSV and return a DataFrame."""
    return pd.read_csv(path)

def clean_data(data):
    """Clean duplicates, types, missing values, and create revenue fields."""
    data = data.copy()
    data.columns = data.columns.str.strip()
    data["Order_Date"] = pd.to_datetime(data["Order_Date"], errors="coerce")
    for col in ["Quantity", "Unit_Price", "Discount"]:
        data[col] = pd.to_numeric(data[col], errors="coerce")
    data = data.drop_duplicates()
    # Quantity is required for revenue; drop rows where it is missing or invalid.
    data = data[data["Quantity"].notna() & (data["Quantity"] > 0)]
    # Fill categorical gaps with a transparent label rather than guessing a region.
    data["Region"] = data["Region"].fillna("Unknown")
    data["Customer_ID"] = data["Customer_ID"].fillna("Unknown")
    data["Product"] = data["Product"].fillna("Unknown")
    data["Category"] = data["Category"].fillna("Unknown")
    data["Discount"] = data["Discount"].fillna(0).clip(0, 1)
    data = data[data["Unit_Price"].notna() & (data["Unit_Price"] >= 0)]
    data["Gross_Sales"] = data["Quantity"] * data["Unit_Price"]
    data["Revenue"] = data["Gross_Sales"] * (1 - data["Discount"])
    data["Month"] = data["Order_Date"].dt.to_period("M").astype(str)
    return data

def create_visuals(data):
    # Product revenue bar chart
    product = data.groupby("Product")["Revenue"].sum().sort_values(ascending=True)
    plt.figure(figsize=(9, 5))
    product.plot(kind="barh")
    plt.title("Revenue by Product")
    plt.xlabel("Revenue")
    plt.ylabel("Product")
    plt.tight_layout()
    plt.savefig(FIGURES / "revenue_by_product.png", dpi=150)
    plt.close()

    # Monthly trend
    monthly = data.groupby("Month")["Revenue"].sum()
    plt.figure(figsize=(10, 5))
    monthly.plot(kind="line", marker="o")
    plt.title("Monthly Revenue Trend")
    plt.xlabel("Month")
    plt.ylabel("Revenue")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(FIGURES / "monthly_revenue_trend.png", dpi=150)
    plt.close()

    # Regional performance
    region = data.groupby("Region")["Revenue"].sum().sort_values(ascending=False)
    plt.figure(figsize=(8, 5))
    region.plot(kind="bar")
    plt.title("Revenue by Region")
    plt.xlabel("Region")
    plt.ylabel("Revenue")
    plt.tight_layout()
    plt.savefig(FIGURES / "revenue_by_region.png", dpi=150)
    plt.close()

    # Correlation heatmap using Matplotlib
    numeric = data[["Quantity", "Unit_Price", "Discount", "Gross_Sales", "Revenue"]].corr(numeric_only=True)
    plt.figure(figsize=(7, 5))
    plt.imshow(numeric, vmin=-1, vmax=1, aspect="auto")
    plt.colorbar(label="Correlation")
    plt.xticks(range(len(numeric.columns)), numeric.columns, rotation=45, ha="right")
    plt.yticks(range(len(numeric.index)), numeric.index)
    for i in range(len(numeric.index)):
        for j in range(len(numeric.columns)):
            plt.text(j, i, f"{numeric.iloc[i, j]:.2f}", ha="center", va="center")
    plt.title("Numeric Feature Correlation")
    plt.tight_layout()
    plt.savefig(FIGURES / "correlation_heatmap.png", dpi=150)
    plt.close()

def main():
    raw = load_data()
    cleaned = clean_data(raw)
    cleaned.to_csv(CLEAN, index=False)
    create_visuals(cleaned)
    summary = {
        "raw_rows": len(raw),
        "clean_rows": len(cleaned),
        "duplicate_rows_removed": int(raw.duplicated().sum()),
        "total_revenue": round(float(cleaned["Revenue"].sum()), 2),
        "average_order_revenue": round(float(cleaned["Revenue"].mean()), 2),
        "top_product": str(cleaned.groupby("Product")["Revenue"].sum().idxmax()),
        "top_region": str(cleaned.groupby("Region")["Revenue"].sum().idxmax()),
        "date_start": str(cleaned["Order_Date"].min().date()),
        "date_end": str(cleaned["Order_Date"].max().date()),
    }
    (REPORTS / "summary_metrics.json").write_text(__import__("json").dumps(summary, indent=2))
    product = cleaned.groupby("Product", as_index=False)["Revenue"].sum().sort_values("Revenue", ascending=False)
    region = cleaned.groupby("Region", as_index=False)["Revenue"].sum().sort_values("Revenue", ascending=False)
    monthly = cleaned.groupby("Month", as_index=False)["Revenue"].sum()
    with (REPORTS / "eda_report.md").open("w", encoding="utf-8") as f:
        f.write("# Retail Sales EDA Report\\n\\n")
        f.write("## Data quality\\n")
        f.write(f"- Raw rows: {len(raw)}\\n- Clean rows: {len(cleaned)}\\n")
        f.write(f"- Duplicate rows removed: {raw.duplicated().sum()}\\n")
        f.write(f"- Missing quantity rows excluded: {raw['Quantity'].isna().sum()}\\n\\n")
        f.write("## KPI summary\\n")
        for key, value in summary.items(): f.write(f"- **{key.replace('_',' ').title()}**: {value}\\n")
        f.write("\\n## Revenue by product\\n\\n" + product.to_markdown(index=False) + "\\n")
        f.write("\\n## Revenue by region\\n\\n" + region.to_markdown(index=False) + "\\n")
        f.write("\\n## Monthly revenue\\n\\n" + monthly.to_markdown(index=False) + "\\n")
        f.write("\\n## Interpretation\\n")
        f.write("- Product and regional rankings are based on total calculated revenue.\\n")
        f.write("- Monthly totals help reveal seasonality, growth, or dips; confirm patterns with more years of data.\\n")
        f.write("- Synthetic sample data is for demonstrating the workflow, not for real business decisions.\\n")
    print("Analysis complete.")
    print(__import__("json").dumps(summary, indent=2))

if __name__ == "__main__":
    main()
